<?php 
	$ios = array(
		'app_ver' =>		"1.0",
		'force_update' =>	"1",	
	);
