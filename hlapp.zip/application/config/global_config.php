<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*************************                       all page config                             *************************/ 


$config['PRODUCTION_HOST'] = array('hlapp.stheadline.com','192.168.148.159');

$config['PRODUCTION_HOST'] = array('hlapp.stheadline.com','192.168.149.159','192.168.148.159');

$config['ALLOW_GEN_IP'] = array('210.3.98.54','203.80.0.5');
if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
  $_SERVER['HTTPS'] = 'on';
}
$config['PROTOCOL'] = ( isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on' ) ? 'https' : 'http';
$config['base_suffix']    = '';
$config['base_url']    = $config['PROTOCOL'] . '://'.$_SERVER['HTTP_HOST'].'/' . $config['base_suffix'];
#Read cache only, all DB connection aborted
$config['cache_only'] = false;

/*
 *	PROD config
 */
if(in_array($_SERVER['SERVER_NAME'], $config['PRODUCTION_HOST']) ){ 
	define('ENV', 'PROD');
	ini_set('display_errors', 'Off');
	error_reporting(0);
	$config['img_server_config'] = array(
		"hostname"	=>	"192.168.148.50",
		"username"	=>	"ftp_pop",
		"password"	=>	"XaqaM4f9Vn",
		"debug"		=>	false,
	);
	
	//img_path
	$config['daily_img_url'] = "https://static.stheadline.com/stheadline/";
	$config['instant_img_url'] = "https://static.stheadline.com/stheadline/inewsmedia/";
	$config['popnews_img_url'] = "https://static.stheadline.com/stheadline/pop/";
	$config['life_img_url'] = "https://static.stheadline.com/stheadline/";
	$config['column_img_url'] = "https://static.stheadline.com/stheadline/";
	$config['hl_app_img_url'] = "https://static.stheadline.com/stheadline/";
	
	
	$config['imgwd_para'] = "10000p10000/0x0/100/hd/";
	$config['imgwd_para_nowm'] = "10000p10000/0x0/100/none/";
	$config['imgwd_md5'] = str_ireplace('/','',$config['imgwd_para']).'{src}';
	$config['imgwd_md5_nowm'] = str_ireplace('/','',$config['imgwd_para_nowm']).'{src}';
	$config['imgwd_src'] = array(
		 '1'=>'stheadline/inewsmedia/',
		 '2'=>'stheadline/',
		 '3'=>'stheadline/pop/',
		 '4'=>'stheadline/',
		 '5'=>'stheadline/',
	);
	//$config['imgwd_prefix'] = "http://192.168.148.170/f/".$config['imgwd_para'];
	$config['imgwd_prefix'] = "https://image.stheadline.com/f/".$config['imgwd_para'];
	$config['imgwd_prefix_nowm'] = "https://image.stheadline.com/f/".$config['imgwd_para_nowm'];
	
	
	//vdo
	$config['popnews_vdo_url'] = "http://vod6.hkheadline.com/";
	$config['life_vdo_url'] = "http://vod6.hkheadline.com/";
	$config['instant_vdo_url'] = "https://static.stheadline.com/stheadline/inewsmedia/";
	$config['solr'] = array(
		"project"       => "appcollect",
		"http_root"     => "192.168.148.106:8983/solr/",
		"debug"         => false,
		"is_cloud_mode" => true,
		"min_score"     => 0.1,
	);
}

/*
 *	DEV config
 */
else{
	define('ENV', 'DEV');	
	$config['img_server_config'] = array(
		"hostname"	=>	"192.168.149.50",
		"username"	=>	"ftp_test",
		"password"	=>	"scuj4y34",
		"debug"		=>	true,
	);
	
	//img_path
	$config['daily_img_url'] = "http://192.168.148.107/stheadline/";
	$config['instant_img_url'] = "http://192.168.149.49/stheadline/inewsmedia/";
	$config['popnews_img_url'] = "http://192.168.149.49/stheadline/pop/";
	$config['life_img_url'] = "http://192.168.148.107/stheadline/";
	$config['column_img_url'] = "http://192.168.148.107/stheadline/";
	$config['hl_app_img_url'] = "http://192.168.149.49/stheadline/";
	
	$config['imgwd_para'] = "10000p10000/0x0/100/hd/";
	$config['imgwd_md5'] = str_ireplace('/','',$config['imgwd_para']).'{src}';
	$config['imgwd_src'] = array(
		 '1'=>'stheadline/inewsmedia/',
		 '2'=>'stheadline/',
		 '3'=>'stheadline/pop/',
		 '4'=>'stheadline/',
		 '5'=>'stheadline/',
	);
	$config['imgwd_prefix'] = "http://192.168.148.170/f/".$config['imgwd_para'];
	
	//vdo
	$config['popnews_vdo_url'] = "http://dev.vod6.stheadline.com/";
	$config['life_vdo_url'] = "http://vod6.hkheadline.com/";
	$config['instant_vdo_url'] = "http://static.stheadline.com/stheadline/inewsmedia/";
	$config['solr'] = array(
		"project"       => "appcollect",
		"http_root"     => "192.168.149.106:8983/solr/",
		"debug"         => false,
		"is_cloud_mode" => true,
		"min_score"     => 0.1,
	);
}

//text releated
$config['new_line'] = array('<br>', '<br />');

$config['search_filter'] = array(
	"~","`","!","@","#","$","%","^","&","*","(",")","-","_","=","+","[","]","{","}","\\","|",";",":","'",'"',",",".","?","/","<",">",
	"～","！","＠","＃","＄","％","＾","＆","＊","（","）","＿","－","＋","＝","｛","｝","［","］","＼","｜","；","：","＇","＂","．","／","＜","＞","，","？","｀",
	"~","·","！","@","#","￥","%","……","&","*","（","）","——","-","+","=","【","】","{","}","、","|","；","：","‘","“","”","’","《","》","，","。","？","、",
	"～","·","＠","＃","￥","％","……","＆","×","（","）","——","－","＋","＝","｛","｝","【","】","｜","＼","：","；","‘","“","”","《","》","，","、","　","＄","︿","＊","＿","＜","＞","／","［","］","‵","＂",'「','」'
);
$config['unicode_filter'] = array(
	"\ufeff",
);

$config['headlife_cat'] = array(57,58,60,61,63,65,67,68);

//select limit
$config['day_before'] = 90;			//For date limit
$config['column_day_before'] = 30;	//For date limit

//number_of_topic
$config['total_topic'] = 20;	
	
//number_of_list_item
$config['total_list_item'] = 100;	//topic instant
$config['total_columns_list_item'] = 11;	
$config['total_popnews_list_item'] = 20;	
$config['total_life_list_item'] = 40;	
$config['search_list_item'] = 50;	

//cache time(SEC)
$config['force_cache'] = -1;
$config['list_time'] = 600;   
$config['detail_time'] = 300;
$config['interest_time'] = 300;
//****TEST ONLY****//
$config['list_time'] = 120;  
$config['detail_time'] = 60;
$config['interest_time'] = 60;

//json cache path
$config['detail_path']	= 'json/{section}/detail/{page}/{id}.json';
$config['list_path']	= 'json/{section}/list/{section}_list_{cat}.json';
$config['hit_list_path'] = 'json/{section}_hit_list.json';
$config['app_config_path'] = 'json/app_config.json';
$config['hot_search_path'] = 'json/hotSearch.json';
$config['section_list_path'] = 'json/section_list.json';
$config['hotmob_adcode_path'] = 'json/hotmob_adcode.json';


$config['daily_top_list_path'] = 'json/daily-newest-top-list.json';
$config['instant_top_list_path'] = 'json/instant-newest-top-list.json';
$config['interest_list_path'] = 'json/interest/list_{page}.json';
$config['highlight_path'] = 'json/highlight.json';
$config['columns_path'] = 'json/columns/list_{id}.json';

$config['ads_cat_list_pos'] = array(
	"index" => array(2,4,7,10,13,16),	//首頁
	"1-1" => array(2,4,7,10,13,16),	//即時-港聞
	"1-2" => array(2,4,7,10,13,16),	//即時-娛樂
	"1-3" => array(2,4,7,10,13,16),	//即時-中國
	"1-4" => array(2,4,7,10,13,16),	//即時-國際
	"1-5" => array(2,4,7,10,13,16),	//即時-地產
	"1-6" => array(2,4,7,10,13,16),	//即時-財經
	"1-7" => array(2,4,7,10,13,16),	//即時-體育
	"2-1" => array(2,4,7,10,13,16),	//日報-港聞
	"2-2" => array(2,4,7,10,13,16),	//日報-中國
	"2-3" => array(2,4,7,10,13,16),	//日報-國際
	"2-4" => array(2,4,7,10,13,16),	//日報-地產
	"2-5" => array(2,4,7,10,13,16),	//日報-財經
	"2-6" => array(2,4,7,10,13,16),	//日報-體育
	"2-7" => array(2,4,7,10,13,16),	//日報-副刊
	"2-8" => array(2,4,7,10,13,16),	//日報-娛樂
	"2-9" => array(2,4,7,10,13,16),	//日報-馬經
	"4-1" => array(2,4,7,10,13,16),	//生活-旅遊
	"4-2" => array(2,4,7,10,13,16),	//生活-飲食
	"4-3" => array(2,4,7,10,13,16),	//生活-影音
	"4-4" => array(2,4,7,10,13,16),	//生活-駕駛
	"4-5" => array(2,4,7,10,13,16),	//生活-時尚
	"4-6" => array(2,4,7,10,13,16),	//生活-健康
	"3" => array(2,4,7,10,13,16),	//影片
	"5" => array(2,4,7,10,13,16),	//專欄
	"columns" => array(3),	//個入專欄列表
);
foreach($config['ads_cat_list_pos'] as $k => $v){
	if(!in_array($k,array("columns", "3","index"))){
		$config['ads_cat_list_pos']['detail-'.$k] = array(1,2,3);
	}
}

$config['hotmob_adcode'] = array(
	
	"instantlist" => array(
		"highlight" => "headline_android_banner_realtime_main",
		"1" => "headline_android_banner_realtime_list_local",
		"2" => "headline_android_banner_realtime_list_entertainment",
		"3" => "headline_android_banner_realtime_list_china",
		"4" => "headline_android_banner_realtime_list_international",
		"5" => "headline_android_banner_realtime_list_realestate",
		"6" => "headline_android_banner_realtime_list_finance",
		"7" => "headline_android_banner_realtime_list_sport",
		"topic" => "headline_android_banner_realtime_list_feature",
		
	),
	"instantdetail" => array(
		"1" => "headline_android_banner_realtime_local",
		"2" => "headline_android_banner_realtime_entertainment",
		"3" => "headline_android_banner_realtime_china",
		"4" => "headline_android_banner_realtime_international",
		"5" => "headline_android_banner_realtime_realestate",
		"6" => "headline_android_banner_realtime_finance",
		"7" => "headline_android_banner_realtime_sport",					
	),


	"dailylist" => array(
		"1" => "headline_android_banner_daily_list_local",
		"2" => "headline_android_banner_daily_list_china",
		"3" => "headline_android_banner_daily_list_international",
		"4" => "headline_android_banner_daily_list_realestate",
		"5" => "headline_android_banner_daily_list_finance",
		"6" => "headline_android_banner_daily_list_sport",
		"7" => "headline_android_banner_daily_list_leisure",
		"8" => "headline_android_banner_daily_list_entertainment",
		"9" => "headline_android_banner_daily_list_racing",
	),
	"dailydetail" => array(
		"1" => "headline_android_banner_daily_local",
		"2" => "headline_android_banner_daily_china",
		"3" => "headline_android_banner_daily_international",
		"4" => "headline_android_banner_daily_realestate",
		"5" => "headline_android_banner_daily_finance",
		"6" => "headline_android_banner_daily_sport",
		"7" => "headline_android_banner_daily_leisure",
		"8" => "headline_android_banner_daily_entertainment",
		"9" => "headline_android_banner_daily_racing"					
	),			

	"headlifelist" => array(
		"1" => "headline_android_banner_lifestyle_list_1",
		"2" => "headline_android_banner_lifestyle_list_2",
		"3" => "headline_android_banner_lifestyle_list_3",
		"4" => "headline_android_banner_lifestyle_list_4",
		"5" => "headline_android_banner_lifestyle_list_5",
		"6" => "headline_android_banner_lifestyle_list_6",
		"7" => "headline_android_banner_lifestyle_list_7",
		"8" => "headline_android_banner_lifestyle_list_8",
	),
	"headlifedetail" => array(
		"1" => "headline_android_banner_lifestyle_1",
		"2" => "headline_android_banner_lifestyle_2",
		"3" => "headline_android_banner_lifestyle_3",
		"4" => "headline_android_banner_lifestyle_4",
		"5" => "headline_android_banner_lifestyle_5",
		"6" => "headline_android_banner_lifestyle_6",
		"7" => "headline_android_banner_lifestyle_7",
		"8" => "headline_android_banner_lifestyle_8",				
	),
		
			
	"columns" => array(
					"list" => "headline_android_banner_column_list",
					"other" => "headline_android_banner_column_other",
					"author" => "headline_android_banner_column_list_author",
					"1" => "headline_android_banner_daily_column",
					"2" => "headline_android_banner_daily_column",
				),	
		
	"popnews" => array("headline_android_banner_popnews")
);
//app_config
// $app_config['img']['daily_img_url'] = 		$config['daily_img_url'];
// $app_config['img']['instant_img_url'] =		$config['instant_img_url'];
// $app_config['img']['popnews_img_url'] =		$config['popnews_img_url'];
// $app_config['img']['life_img_url'] =		$config['life_img_url'];
// $app_config['img']['column_img_url'] =		$config['column_img_url'];
// $app_config['img']['hl_app_img_url'] =		$config['hl_app_img_url'];

$app_config['img']['imgwd_para'] = $config['imgwd_para'];
$app_config['img']['imgwd_prefix'] = $config['imgwd_prefix'];





$app_config['img']['daily_img_url'] = 		'';
$app_config['img']['instant_img_url'] =		'';
$app_config['img']['popnews_img_url'] =		'';
$app_config['img']['life_img_url'] =		'';
$app_config['img']['column_img_url'] =		'';
$app_config['img']['hl_app_img_url'] =		'';


$app_config['vdo']['popnews_vdo_url'] =		$config['popnews_vdo_url'];
$app_config['vdo']['life_vdo_url'] =		$config['life_vdo_url'];
$app_config['vdo']['instant_vdo_url'] =		$config['instant_vdo_url'];

$app_config['api']['api_highlight'] = 		"highlight";
$app_config['api']['api_detail'] =			"detail/[section]/[id]/";
$app_config['api']['api_column_list'] =		"columns/[columnid]";
$app_config['api']['api_list'] =			"list/[section]/[cat]/";//新闻列表
$app_config['api']['api_section_cat'] =		"section/";//栏目分类列表

$app_config['api']['api_sp_search'] =		"sp_search/";
$app_config['api']['api_search'] =			"search/[keyword]/[page]";
$app_config['api']['api_hot_search'] =		"hot_search/";//熱門關鍵字

$app_config['api']['api_hit_list'] =		"hit_list/[section]";//十大熱門daily or instant only
$app_config['api']['api_interest'] =		"interest";
$app_config['api']['api_special'] =			"special";


$app_config['api']['api_list_ads'] = 		"ads/[section]/[cat]";

//error_code
require_once('hlapp/error_code.php');
$app_config['error'] = $error_code;
//android app version
require_once('hlapp/android.php');
$app_config['android'] = $android;
//ios app version
require_once('hlapp/ios.php');
$app_config['ios'] = $ios;	
$config['app_config'] = $app_config;





